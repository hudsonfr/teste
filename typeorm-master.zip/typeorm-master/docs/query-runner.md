# Query Runner

`QueryRunner` is used to perform database-related queries.

TBD.