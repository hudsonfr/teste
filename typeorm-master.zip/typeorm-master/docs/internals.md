# Internals

This guide explains how things are working in TypeORM. 
It will be useful for our contributors.

TBD. 