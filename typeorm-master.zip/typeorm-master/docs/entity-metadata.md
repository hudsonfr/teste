# Entity Metadata

Entity metadata and all related metadata classes contain information about entities,
their columns, indices, relations and other entity-related information you can use
to create more complex applications or extensions for TypeORM.

TBD.