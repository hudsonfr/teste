# Internals

本指南解释了TypeORM中的工作原理。
这对我们的贡献者很有用。

待定。
