# 支持

### 发现错误或想提出新功能？

如果你发现了 bug，issue，或者你只是想提出一个新功能，请[在 github 上创建 issue](https://github.com/typeorm/typeorm/issues)。

### 有问题？

如果你有疑问，可以在[StackOverflow](https://stackoverflow.com/questions/tagged/typeorm)上询问。

### 想要社区支持？

如果你需要社区支持，或者只是想与 TypeORM 爱好者和用户聊天，你可以在[gitter]（https://gitter.im/typeorm/typeorm）中进行。

### 想要专业的商业支持？

TypeORM 核心团队随时准备提供专业的商业支持。
我们愿意与世界任何地方的任何团队合作。
[请联系我们](mailto:support@typeorm.io)。
