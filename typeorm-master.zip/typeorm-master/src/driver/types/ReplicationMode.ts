export type ReplicationMode = "master" | "slave";
